extends Node

func _init() -> void:
	VML.add_hook("game:modify_damage", _on_modify_damage, 5)

func _on_modify_damage(current: Variant, _amount: int, _weapon: String) -> Variant:
	return current + 5.0
